import java.util.Objects;

public class Child {
    public String name;
    public String surname;
    public int age;
    Gender gender;
    Parent parent;

    public Child(String name, String surname, int age, Gender gender, Parent parent) {
        this.name = name;
        this.surname = surname;
        this.age = age;
        this.gender = gender;
        this.parent = parent;
    }

    public void watch() {
        System.out.println("Ну, погоди");
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Child child = (Child) o;
        return age == child.age && Objects.equals(name, child.name) && Objects.equals(surname, child.surname) && gender == child.gender && Objects.equals(parent, child.parent);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, surname, age, gender, parent);
    }

    @Override
    public String toString() {
        return "Ребенок {" +
                "имя='" + name + '\'' +
                ", фамилия='" + surname + '\'' +
                ", возраст=" + age +
                ", пол=" + gender +
                ", родитель" + parent +
                '}';
    }
}
