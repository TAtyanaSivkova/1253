import javax.print.attribute.standard.MediaName;

public enum Gender {
    MEN,
    WOMAN;
}
