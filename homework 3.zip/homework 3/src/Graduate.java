import java.util.Objects;

public class Graduate extends School {
    SubjectForTheExam subjectForTheExam;
    public Double gpa;

    public Graduate(String name, String surname, int age, Gender gender, Parent parent, String schoolName, String grade, HealthGroup healthGroup, SubjectForTheExam subjectForTheExam, Double gpa) {
        super(name, surname, age, gender, parent, schoolName, grade, healthGroup);
        this.subjectForTheExam = subjectForTheExam;
        this.gpa = gpa;
    }


    @Override
    public void watch() {
        System.out.println("Эйфория");
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        Graduate graduate = (Graduate) o;
        return subjectForTheExam == graduate.subjectForTheExam && Objects.equals(gpa, graduate.gpa);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), subjectForTheExam, gpa);
    }

    @Override
    public String toString() {
        return super.toString() + ", школа {" +
                "название школы='" + schoolName + '\'' +
                ", класс='" + grade + '\'' +
                ", группа здоровья=" + healthGroup +
                '}' + ", выпускник {" +
                "ЕГЭ по выбору=" + subjectForTheExam +
                ", средний балл аттестата=" + gpa +
                '}';
    }
}

