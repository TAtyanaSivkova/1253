public enum HealthGroup {
    BASIC,
    PREPARATORY,
    SPECIAL;
}
