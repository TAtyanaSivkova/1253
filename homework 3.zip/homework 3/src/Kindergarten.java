import java.util.Objects;

public class Kindergarten extends Child {
    public String nameKindergarten;
    public String nameGroup;
    public String surnameOfTheEducator;

    public Kindergarten(String name, String surname, int age, Gender gender, Parent parent, String nameKindergarten, String nameGroup, String surnameOfTheEducator) {
        super(name, surname, age, gender, parent);
        this.nameKindergarten = nameKindergarten;
        this.nameGroup = nameGroup;
        this.surnameOfTheEducator = surnameOfTheEducator;
    }

    @Override
    public void watch() {
        System.out.println("Человек паук");
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        Kindergarten that = (Kindergarten) o;
        return Objects.equals(nameKindergarten, that.nameKindergarten) && Objects.equals(nameGroup, that.nameGroup) && Objects.equals(surnameOfTheEducator, that.surnameOfTheEducator);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), nameKindergarten, nameGroup, surnameOfTheEducator);
    }

    @Override
    public String toString() {
        return super.toString() + ", детский сад {" +
                "название садика='" + nameKindergarten + '\'' +
                ", название группы='" + nameGroup + '\'' +
                ", фамилия воспитателя='" + surnameOfTheEducator + '\'' +
                '}';
    }
}




