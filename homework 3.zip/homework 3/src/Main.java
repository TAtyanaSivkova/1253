import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        List<Child> list = new ArrayList<>();
        list.add(new School("Василий", "Петров", 8, Gender.MEN, new Parent("Ольга", "Петрова", "+79824758634"), "Мастерград", "2д", HealthGroup.BASIC));
        list.add(new Child("Ольга", "Волкова", 2, Gender.WOMAN, new Parent("Дарья", "Волкова", "+79223578945")));
        list.add(new Kindergarten("Илья", "Пушкин", 5, Gender.MEN, new Parent("Татьяна", "Пушкина", "+79576312587"), "Светлячок", "Паучки", "Котяева"));
        list.add(new Graduate("Светлана", "Ульянова", 17, Gender.WOMAN, new Parent("Екатерина", "Ульянова", "+79804578654"), "Синтез", "11а", HealthGroup.PREPARATORY, SubjectForTheExam.HISTORY, 4.2));

        list.forEach(child -> {
            System.out.println(child);
        });
        list.forEach(child -> {
            child.watch();
        });
    }


}
