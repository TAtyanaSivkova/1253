import java.util.Objects;

public class Parent {
    public String nameParent;
    public String surnameParent;
    public String phoneNumber;

    public Parent(String nameParent, String surnameParent, String phoneNumber) {
        this.nameParent = nameParent;
        this.surnameParent = surnameParent;
        this.phoneNumber = phoneNumber;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Parent parent = (Parent) o;
        return Objects.equals(nameParent, parent.nameParent) && Objects.equals(surnameParent, parent.surnameParent) && Objects.equals(phoneNumber, parent.phoneNumber);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nameParent, surnameParent, phoneNumber);
    }

    @Override
    public String toString() {
        return " {" +
                "имя='" + nameParent + '\'' +
                ", фамилия='" + surnameParent + '\'' +
                ", номер телефона='" + phoneNumber + '\'' +
                '}';
    }
}
