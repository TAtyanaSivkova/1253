import java.util.Objects;

public class School extends Child {
    public String schoolName;
    public String grade;
    HealthGroup healthGroup;

    public School(String name, String surname, int age, Gender gender, Parent parent, String schoolName, String grade, HealthGroup healthGroup) {
        super(name, surname, age, gender, parent);
        this.schoolName = schoolName;
        this.grade = grade;
        this.healthGroup = healthGroup;
    }

    @Override
    public void watch() {
        System.out.println("Уэнздей");
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        School school = (School) o;
        return Objects.equals(schoolName, school.schoolName) && Objects.equals(grade, school.grade) && healthGroup == school.healthGroup;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), schoolName, grade, healthGroup);
    }

    @Override
    public String toString() {
        return super.toString() + ", школа {" +
                "название школы='" + schoolName + '\'' +
                ", класс='" + grade + '\'' +
                ", группа здоровья=" + healthGroup +
                '}';
    }
}
